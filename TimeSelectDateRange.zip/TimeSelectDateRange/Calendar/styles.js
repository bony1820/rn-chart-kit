import { ScaledSheet } from 'react-native-size-matters';
import { useTheme } from '@/Hooks';

export default function useStyles() {
  const { FontSize, Colors } = useTheme();
  return ScaledSheet.create({
    container: {},
  });
}
