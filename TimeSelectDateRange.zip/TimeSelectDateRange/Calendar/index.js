import React from 'react';
import { Calendar } from 'react-native-calendars';
import moment from 'moment';

export default function CalendarCustom({
  onSelectDay,
  theme,
  initialRange,
  ...props
}) {
  const [state, setState] = React.useState({
    isFromDatePicked: false,
    isToDatePicked: false,
    markedDates: {},
  });

  React.useEffect(() => {
    setupInitialRange();
  }, [initialRange]);

  const onDayPress = day => {
    const isFutureDay = moment().isBefore(day.dateString);
    if (isFutureDay) return;
    if (
      !state.isFromDatePicked ||
      (state.isFromDatePicked && state.isToDatePicked)
    ) {
      setupStartMarker(day);
    } else if (!state.isToDatePicked) {
      const markedDates = { ...state.markedDates };
      const [mMarkedDates, range] = setupMarkedDates(
        state.fromDate,
        day.dateString,
        markedDates,
      );
      if (range >= 0) {
        setState({
          isFromDatePicked: true,
          isToDatePicked: true,
          markedDates: mMarkedDates,
        });
        onSelectDay({
          fromDate: state.fromDate,
          endDate: day.dateString,
        });
      } else {
        setupStartMarker(day);
      }
    }
  };

  const setupStartMarker = day => {
    const markedDates = {
      [day.dateString]: {
        startingDay: true,
        color: theme.markColor,
        textColor: theme.markTextColor,
      },
    };
    setState({
      isFromDatePicked: true,
      isToDatePicked: false,
      fromDate: day.dateString,
      markedDates,
    });
  };

  const setupMarkedDates = (fromDate, toDate, markedDates) => {
    const mFromDate = moment(fromDate);
    const mToDate = moment(toDate);
    const range = mToDate.diff(mFromDate, 'day');
    if (range >= 0) {
      if (range == 0) {
        markedDates = {
          [toDate]: { color: theme.markColor, textColor: theme.markTextColor },
        };
      } else {
        for (let i = 1; i <= range; i++) {
          const tempDate = mFromDate.add(1, 'day').format('YYYY-MM-DD');
          if (i < range) {
            markedDates[tempDate] = {
              color: theme.markColor,
              textColor: theme.markTextColor,
            };
          } else {
            markedDates[tempDate] = {
              endingDay: true,
              color: theme.markColor,
              textColor: theme.markTextColor,
            };
          }
        }
      }
    }
    return [markedDates, range];
  };

  const setupInitialRange = () => {
    if (!initialRange) return;
    const { fromDate, endDate } = initialRange;
    const markedDates = {
      [fromDate]: {
        startingDay: true,
        color: theme.markColor,
        textColor: theme.markTextColor,
      },
    };
    const [mMarkedDates, range] = setupMarkedDates(
      fromDate,
      endDate,
      markedDates,
    );
    setState({ markedDates: mMarkedDates, fromDate });
  };

  return (
    <Calendar
      {...props}
      markingType="period"
      current={state.fromDate}
      markedDates={state.markedDates}
      onDayPress={day => {
        onDayPress(day);
      }}
    />
  );
}

CalendarCustom.defaultProps = {
  theme: { markColor: '#00adf5', markTextColor: '#ffffff' },
  onSelectDay: () => {},
};
