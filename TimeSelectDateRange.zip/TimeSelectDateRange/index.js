import React from 'react';
import {
  View,
  TouchableOpacity,
  LayoutAnimation,
  UIManager,
  Platform,
} from 'react-native';
import { Text } from 'react-native-paper';
import { useTranslation } from 'react-i18next';
import moment from 'moment';
import CalendarCustom from './Calendar';

import useStyles from './styles';
import _ from 'lodash';

if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

function Button({ title, onPress }) {
  const styles = useStyles();
  return (
    <TouchableOpacity onPress={onPress} style={styles.button}>
      <Text style={styles.buttonText}>{title}</Text>
    </TouchableOpacity>
  );
}
export default function TimeSelectDateRange({
  onSelectDayRange,
  initialRange,
}) {
  const { t } = useTranslation();
  const styles = useStyles();
  const [isShowPicker, setShowPicker] = React.useState(false);
  const [selectedDayRange, setDayRange] = React.useState(initialRange);

  const onSelectToDay = () => {
    setDayRange({
      fromDate: moment().format('YYYY-MM-DD'),
      endDate: moment().format('YYYY-MM-DD'),
    });
  };

  const onSelectYesterday = () => {
    setDayRange({
      fromDate: moment().subtract(1, 'day').format('YYYY-MM-DD'),
      endDate: moment().format('YYYY-MM-DD'),
    });
  };

  const onSelectLast7Day = () => {
    setDayRange({
      fromDate: moment().subtract(1, 'week').format('YYYY-MM-DD'),
      endDate: moment().format('YYYY-MM-DD'),
    });
  };

  const onSelectThisWeek = () => {
    setDayRange({
      fromDate: moment().startOf('week').format('YYYY-MM-DD'),
      endDate: moment().format('YYYY-MM-DD'),
    });
  };

  const onSelectLastWeek = () => {
    setDayRange({
      fromDate: moment()
        .subtract(1, 'week')
        .startOf('week')
        .format('YYYY-MM-DD'),
      endDate: moment().subtract(1, 'week').endOf('week').format('YYYY-MM-DD'),
    });
  };

  const onSelectThisMonth = () => {
    setDayRange({
      fromDate: moment().startOf('month').format('YYYY-MM-DD'),
      endDate: moment().format('YYYY-MM-DD'),
    });
  };

  const onSelectLastMonth = () => {
    setDayRange({
      fromDate: moment()
        .subtract(1, 'month')
        .startOf('month')
        .format('YYYY-MM-DD'),
      endDate: moment()
        .subtract(1, 'month')
        .endOf('month')
        .format('YYYY-MM-DD'),
    });
  };

  const dateRange = React.useMemo(() => {
    let fromDate;
    let endDate;
    if (!selectedDayRange) {
      fromDate = moment().format('MMMM DD, YYYY');
      endDate = fromDate;
    } else {
      fromDate = moment(selectedDayRange.fromDate).format('MMMM DD, YYYY');
      endDate = moment(selectedDayRange.endDate).format('MMMM DD, YYYY');
    }
    return `${fromDate} - ${endDate}`;
  }, [selectedDayRange]);

  React.useEffect(() => {
    if (selectedDayRange && !isShowPicker) {
      onSelectDayRange && onSelectDayRange(selectedDayRange);
    }
  }, [selectedDayRange, onSelectDayRange, isShowPicker]);

  React.useEffect(() => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
  }, [isShowPicker]);

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => setShowPicker(!isShowPicker)}>
        <View>
          <Text style={styles.textSelect}>{dateRange}</Text>
        </View>
      </TouchableOpacity>
      {isShowPicker && (
        <View style={styles.dateRangPickerContainer}>
          <View style={styles.datePickerContainer}>
            <CalendarCustom
              onSelectDay={setDayRange}
              initialRange={selectedDayRange}
            />
          </View>
          <View style={styles.buttonContainer}>
            <Button title={t('orderHistory.today')} onPress={onSelectToDay} />
            <Button
              title={t('orderHistory.yesterday')}
              onPress={onSelectYesterday}
            />
            <Button
              title={t('orderHistory.last7Days')}
              onPress={onSelectLast7Day}
            />
            <Button
              title={t('orderHistory.thisWeek')}
              onPress={onSelectThisWeek}
            />
            <Button
              title={t('orderHistory.lastWeek')}
              onPress={onSelectLastWeek}
            />
            <Button
              title={t('orderHistory.thisMonth')}
              onPress={onSelectThisMonth}
            />
            <Button
              title={t('orderHistory.lastMonth')}
              onPress={onSelectLastMonth}
            />
          </View>
        </View>
      )}
    </View>
  );
}

TimeSelectDateRange.defaultProps = {
  onSelectDayRange: () => {},
};
