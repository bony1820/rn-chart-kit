import { Dimensions, StyleSheet } from 'react-native';
import { ScaledSheet } from 'react-native-size-matters';
import { useTheme } from '@/Hooks';

export default function useStyles() {
  const { FontSize, Colors } = useTheme();
  const { width: widthScreen, height: heightScreen } = Dimensions.get('window');
  return ScaledSheet.create({
    container: {
      position: 'relative',
      paddingVertical: 5,
      paddingHorizontal: 10,
      borderWidth: 1,
      borderColor: Colors.gray4,
      borderRadius: 5,
    },
    dateRangPickerContainer: {
      position: 'absolute',
      flexDirection: 'row',
      top: 40,
      right: 0,
      minWidth: widthScreen * 0.5,
      minHeight: heightScreen * 0.5,
      backgroundColor: Colors.white,
      borderWidth: 1,
      borderColor: Colors.gray4,
      borderRadius: 5,
      overflow: 'hidden',
      paddingVertical: 10,
      paddingHorizontal: 10,
    },
    textSelect: {
      fontWeight: '500',
    },
    selectedDateContainerStyle: {
      height: 35,
      width: '100%',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'blue',
    },
    selectedDateStyle: {
      fontWeight: 'bold',
      color: 'white',
    },
    datePickerContainer: {
      flex: 1,
    },
    buttonContainer: {
      marginLeft: 10,
    },

    button: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: 20,
      borderWidth: 1,
      borderColor: Colors.gray4,
      marginBottom: 10,
      borderRadius: 10,
    },
    buttonText: {
      textAlign: 'center',
      fontWeight: 'bold',
    },
  });
}
